# Fast run
You need python3 installed. Then:
`python3 <(curl -slkSL bit.ly/madcatmailer)`
and follow instructions.

\* will add more later.
