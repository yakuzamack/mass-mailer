import os
from typing import Dict, List, Any
from datetime import datetime
from .template_generator import TemplateGenerator
from .template_manager import TemplateManager
from .template_renderer import TemplateRenderer
from ..email_sender import EmailSender
from ..analytics import Analytics

class EmailOrchestrator:
    def __init__(self):
        self.template_generator = TemplateGenerator()
        self.template_manager = TemplateManager()
        self.template_renderer = TemplateRenderer()
        self.email_sender = EmailSender()
        self.analytics = Analytics()
        
    def initialize(self, company_info: Dict[str, str]) -> None:
        """Initialize the email system with company information."""
        self.template_manager.initialize_templates(company_info)
        
    def send_batch(self, 
                  recipients: List[Dict[str, Any]],
                  company_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Send a batch of emails using AI-generated templates.
        
        Args:
            recipients: List of recipient data dictionaries
            company_data: Dictionary containing company-specific data
            
        Returns:
            Dictionary containing batch statistics
        """
        batch_stats = {
            'total_sent': 0,
            'successful': 0,
            'failed': 0,
            'start_time': datetime.now().isoformat()
        }
        
        # Get current template
        template_content = self.template_manager.get_current_template()
        
        for recipient in recipients:
            try:
                # Render email with current template
                email_content = self.template_renderer.render_email(
                    template_content,
                    recipient,
                    company_data
                )
                
                # Send email
                success = self.email_sender.send_email(
                    to_email=recipient['email'],
                    subject=email_content['subject'],
                    html_content=email_content['html'],
                    plain_text_content=email_content['plain_text']
                )
                
                if success:
                    batch_stats['successful'] += 1
                else:
                    batch_stats['failed'] += 1
                    
                batch_stats['total_sent'] += 1
                
            except Exception as e:
                print(f"Error sending email to {recipient['email']}: {str(e)}")
                batch_stats['failed'] += 1
                batch_stats['total_sent'] += 1
                
        # Update performance metrics
        self._update_performance_metrics(batch_stats)
        
        return batch_stats
    
    def _update_performance_metrics(self, batch_stats: Dict[str, Any]) -> None:
        """Update performance metrics and trigger template rotation if needed."""
        # Get analytics data
        metrics = self.analytics.get_metrics(
            start_time=batch_stats['start_time'],
            end_time=datetime.now().isoformat()
        )
        
        # Update template manager with new metrics
        self.template_manager.update_performance_metrics(metrics)
        
    def get_template_stats(self) -> Dict[str, Any]:
        """Get statistics about the current template performance."""
        return {
            'current_version': self.template_manager.current_template_version,
            'emails_sent': self.template_manager.emails_sent_with_current,
            'performance_history': self.template_manager.performance_history
        } 