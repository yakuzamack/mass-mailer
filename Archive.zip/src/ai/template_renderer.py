import os
from typing import Dict, Any
from jinja2 import Environment, FileSystemLoader

class TemplateRenderer:
    def __init__(self, template_dir: str = "templates"):
        self.template_dir = template_dir
        self.env = Environment(
            loader=FileSystemLoader(template_dir),
            autoescape=True
        )
        
    def render_email(self, 
                    template_content: Dict[str, str],
                    recipient_data: Dict[str, Any],
                    company_data: Dict[str, Any]) -> Dict[str, str]:
        """
        Render the email template with the provided content and data.
        
        Args:
            template_content: Dictionary containing AI-generated template components
            recipient_data: Dictionary containing recipient-specific data
            company_data: Dictionary containing company-specific data
            
        Returns:
            Dictionary containing rendered subject and body
        """
        # Load the HTML template
        template = self.env.get_template('template.html')
        
        # Prepare the template data
        template_data = {
            **recipient_data,
            **company_data,
            'subject_line': template_content['subject_line'],
            'greeting': template_content['greeting'],
            'main_body': template_content['main_body'],
            'cta': template_content['cta'],
            'closing': template_content['closing']
        }
        
        # Render the HTML content
        html_content = template.render(**template_data)
        
        # Create plain text version
        plain_text = self._create_plain_text_version(template_content, recipient_data)
        
        return {
            'subject': template_content['subject_line'],
            'html': html_content,
            'plain_text': plain_text
        }
    
    def _create_plain_text_version(self, 
                                 template_content: Dict[str, str],
                                 recipient_data: Dict[str, Any]) -> str:
        """Create a plain text version of the email."""
        return f"""
{template_content['greeting']}

{template_content['main_body']}

{template_content['cta']}

{template_content['closing']}

Best regards,
{recipient_data.get('companyName', '')}
""" 