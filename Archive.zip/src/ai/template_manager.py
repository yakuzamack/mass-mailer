import os
from typing import Dict, List, Optional
from datetime import datetime
import json
from .template_generator import TemplateGenerator

class TemplateManager:
    def __init__(self, template_dir: str = "templates"):
        self.template_dir = template_dir
        self.template_generator = TemplateGenerator()
        self.current_template_version = 0
        self.performance_history = []
        self.emails_sent_with_current = 0
        self.rotation_threshold = 50  # Number of emails before rotation
        
        # Ensure template directory exists
        os.makedirs(template_dir, exist_ok=True)
        
    def initialize_templates(self, company_info: Dict[str, str]) -> None:
        """Generate initial set of templates."""
        # Generate primary template
        primary_template = self.template_generator.generate_template(company_info)
        self._save_template(primary_template, "primary")
        
        # Generate backup template
        backup_template = self.template_generator.generate_template(company_info)
        self._save_template(backup_template, "backup")
        
    def update_performance_metrics(self, metrics: Dict[str, float]) -> None:
        """Update performance metrics and check if rotation is needed."""
        self.performance_history.append({
            'timestamp': datetime.now().isoformat(),
            'metrics': metrics
        })
        
        self.emails_sent_with_current += 1
        
        if self.emails_sent_with_current >= self.rotation_threshold:
            self._rotate_templates()
            
    def _rotate_templates(self) -> None:
        """Rotate templates and generate new ones based on performance."""
        # Load current performance metrics
        latest_metrics = self.performance_history[-1]['metrics']
        
        # Generate new templates based on performance
        company_info = self._load_company_info()
        new_primary = self.template_generator.generate_template(
            company_info,
            performance_metrics=latest_metrics
        )
        new_backup = self.template_generator.generate_backup_template(
            company_info,
            performance_metrics=latest_metrics
        )
        
        # Save new templates
        self._save_template(new_primary, "primary")
        self._save_template(new_backup, "backup")
        
        # Reset counter
        self.emails_sent_with_current = 0
        self.current_template_version += 1
        
    def get_current_template(self) -> Dict[str, str]:
        """Get the current active template."""
        return self._load_template("primary")
        
    def _save_template(self, template: Dict[str, str], template_type: str) -> None:
        """Save template to file."""
        template_path = os.path.join(
            self.template_dir,
            f"{template_type}_template_v{self.current_template_version}.json"
        )
        with open(template_path, 'w') as f:
            json.dump(template, f, indent=2)
            
    def _load_template(self, template_type: str) -> Dict[str, str]:
        """Load template from file."""
        template_path = os.path.join(
            self.template_dir,
            f"{template_type}_template_v{self.current_template_version}.json"
        )
        with open(template_path, 'r') as f:
            return json.load(f)
            
    def _load_company_info(self) -> Dict[str, str]:
        """Load company information from configuration."""
        # This should be implemented based on your configuration management
        # For now, returning a placeholder
        return {
            'name': os.getenv('COMPANY_NAME', 'Company'),
            'industry': os.getenv('COMPANY_INDUSTRY', 'Technology')
        } 