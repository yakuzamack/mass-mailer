import os
import cohere
from typing import Dict, List, Optional
import json
from datetime import datetime

class TemplateGenerator:
    def __init__(self):
        self.co = cohere.Client(os.getenv('COHERE_API_KEY'))
        
    def generate_template(self, 
                         company_info: Dict[str, str],
                         performance_metrics: Optional[Dict[str, float]] = None) -> Dict[str, str]:
        """
        Generate an email template using Cohere's generate endpoint.
        
        Args:
            company_info: Dictionary containing company details
            performance_metrics: Optional metrics from previous email performance
            
        Returns:
            Dictionary containing the generated template components
        """
        # Construct the prompt based on company info and performance metrics
        prompt = self._construct_prompt(company_info, performance_metrics)
        
        # Generate the template using Cohere
        response = self.co.generate(
            prompt=prompt,
            max_tokens=1000,
            temperature=0.7,
            k=0,
            stop_sequences=[],
            return_likelihoods='NONE'
        )
        
        # Parse the generated content into template components
        template_components = self._parse_generated_content(response.generations[0].text)
        
        return template_components
    
    def _construct_prompt(self, 
                         company_info: Dict[str, str],
                         performance_metrics: Optional[Dict[str, float]] = None) -> str:
        """Construct the prompt for the AI model."""
        base_prompt = f"""
        Generate a professional email template for {company_info['name']} with the following components:
        
        1. Subject Line (optimized for engagement)
        2. Greeting
        3. Main Body (clear, concise messaging)
        4. CTA (strong action-driven statement)
        5. Closing
        
        Company Information:
        - Name: {company_info['name']}
        - Industry: {company_info['industry']}
        - Tone: Professional but engaging
        
        Template should include placeholders for:
        - {{name}}
        - {{companyName}}
        - {{url}}
        - {{supportEmail}}
        - {{logoUrl}}
        - {{facebookUrl}}
        - {{twitterUrl}}
        - {{linkedinUrl}}
        - {{currentYear}}
        """
        
        if performance_metrics:
            base_prompt += f"""
            Previous Performance Metrics:
            - Open Rate: {performance_metrics.get('open_rate', 'N/A')}%
            - Click-through Rate: {performance_metrics.get('click_through_rate', 'N/A')}%
            - Response Rate: {performance_metrics.get('response_rate', 'N/A')}%
            
            Please optimize the template to improve these metrics.
            """
        
        return base_prompt
    
    def _parse_generated_content(self, content: str) -> Dict[str, str]:
        """Parse the AI-generated content into template components."""
        # Split content into sections
        sections = content.split('\n\n')
        
        template_components = {
            'subject_line': sections[0].strip(),
            'greeting': sections[1].strip(),
            'main_body': sections[2].strip(),
            'cta': sections[3].strip(),
            'closing': sections[4].strip()
        }
        
        return template_components
    
    def generate_backup_template(self, 
                               company_info: Dict[str, str],
                               performance_metrics: Optional[Dict[str, float]] = None) -> Dict[str, str]:
        """Generate a backup template with slightly different parameters."""
        # Modify temperature for variation
        response = self.co.generate(
            prompt=self._construct_prompt(company_info, performance_metrics),
            max_tokens=1000,
            temperature=0.8,  # Slightly higher temperature for more variation
            k=0,
            stop_sequences=[],
            return_likelihoods='NONE'
        )
        
        return self._parse_generated_content(response.generations[0].text) 